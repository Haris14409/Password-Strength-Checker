""" PASSWORD STRENGTH CHECKER """
# MODULES
import flet 
from flet import * 
import re
import random
import string
import pyperclip
import tkinter as tk
from tkinter import messagebox

# set two lists where controls will be stored

CONTROLS = []
STATUS = []

# set up a decorator function...
# we will be using this to early storeand subsquently retrive the controls we want to animate/change
def store_controls(function):
    def wrapper(*args,**kwargs):
        reference = function(*args,**kwargs)
        if kwargs["control"] == 0:
            CONTROLS.append(reference)
        else:
            STATUS.append(reference)

        return reference

    return wrapper
# Custom function to mimic clipboard functionality
def set_text_to_clipboard(text):
    pyperclip.copy(text)
    
#Custom function to mimic alert functionality CHECKING STUFF
def show_recommendation_dialog(title, message):
    print(f"{title}: {message}")
    #flet.show_message(title, message)
# def show_recommendation_dialog(title, message):
#     root = tk.Tk()
#     root.withdraw()
#     message_box = tk.Toplevel(root)
#     message_box.title(title)
#     message_box.geometry("300x150")  # Set the size of the message box
#     message_box.attributes("-topmost", True)  # Set the message box as the topmost window

#     # Create a label for the message
#     label = tk.Label(message_box, text=message, wraplength=280)
#     label.pack(pady=20)

#     # Create an OK button to close the message box
#     ok_button = tk.Button(message_box, text="OK", command=message_box.destroy)
#     ok_button.pack(pady=10)
    
#     messagebox.showinfo(title, message)

#     root.mainloop()  
# work is not done here yet
# we need to create the logic at this point,before going back to UI
class PasswordStrengthChecker:
    def __init__(self, password):
        self.password = password
        # we will be calling different parts of this class while checking the password
    # check pass length
    def length_check(self):
        # when we call this function, we return integers depending on the length we create UI for show strength
        length = len(self.password)
        if length > 0 and length < 8:
            return 0
        elif length >= 8 and length < 12:
            return 1
        elif length >= 12 and length < 16:
            return 2
        elif length >= 16:
            return 3
        else:
            return 0
        
    # check pass character types
    def character_check(self):
        characters = set(self.password) #
        lower_case = set("abcdefghijklmnopqrstuvwxyz")
        upper_case = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        digits = set("0123456789")
        special_characters = "!@#$%^&*_?~(){}[],.;'=+<>\|"
        score = 0
        #here we are seeing if any lower case sets are in the password 
        #if so we increament the score by 1
        #note :character in this loop is the password.split,

        if any(char in lower_case for char in characters):
            score +=1 
        if any(char in upper_case for char in characters):
            score +=1
        if any(char in digits for char in characters):
            score +=1
        if any(char in special_characters for char in characters):
            score +=1

        return min(score, 3)  # Ensure score is at most 3
        # if score == 1:
        #     return 0
        # elif score == 2:
        #     return 1
        # elif score == 3:
        #     return 2
        # elif score == 4:
        #     return 3

    #check for any repititons
    def repeat_check(self):    
        if len(self.password) == 0:
            return 2
        else:
            for i in range(len(self.password) - 2):
                if self.password[i] == self.password[i +1] == self.password[i + 2]:
                    return 0
            return 1
# check for any reoccuring sequence
    def sequence_check(self):
        if len(self.password) == 0:
            return 2
        else:
            for i in range(len(self.password) - 2):
                # here we check the password within a range of 3 characters,
                if (self.password[i:i+4].isdigit() or
                    self.password[i:i+4].islower() or
                    self.password[i:i+4].isupper()):
                   return 1
            return 0
    def recommend_password(self):
        characters = string.ascii_letters + string.digits + string.punctuation
        password = ''.join(random.choice(characters) for _ in range(16))
        return password

# starting with UI then  move to Logic
class AppWindow(UserControl):
    def __init__(self):
        self.data = ''
        super().__init__()
        


    # first we need  a function to call all the above class inner functions
    def check_password(self, e):
        self.data = e.data
        password_strength_checker = PasswordStrengthChecker(e.data)
        # call the length checker 
        password_length = password_strength_checker.length_check()
        self.password_length_status(password_length) 

        # call the character checker
        character_checker = password_strength_checker.character_check()
        self.character_check_status(character_checker)

        # call the repeat check
        repeat_check = password_strength_checker.repeat_check()
        self.repeat_check_status(repeat_check)

        # call the sequential check
        sequential_check = password_strength_checker.sequence_check()
        self.sequential_check_status(sequential_check)

    # show if criteria satisfied...
    def criteria_satisfied(self, index, status):
        if status == 3:
            STATUS[index].controls[0].offset = transform.Offset(0, 0)
            STATUS[index].controls[0].opacity = 1
            STATUS[index].controls[0].content.value = True
            STATUS[index].controls[0].update()
        else:
            STATUS[index].controls[0].content.value = False
            STATUS[index].controls[0].offset = transform.Offset(-0.5, 0)
            STATUS[index].controls[0].opacity = 0
            STATUS[index].controls[0].update()

    # let's start with showing the length strength
    def password_length_status(self, strength):

        if strength == 0:
            CONTROLS[0].controls[1].controls[0].bgcolor = "red"
            CONTROLS[0].controls[1].controls[0].width = 40
        elif strength == 1:
            CONTROLS[0].controls[1].controls[0].bgcolor = "yellow"
            CONTROLS[0].controls[1].controls[0].width = 70
        elif strength == 2:
            CONTROLS[0].controls[1].controls[0].bgcolor = "green400"
            CONTROLS[0].controls[1].controls[0].width = 100
        elif strength == 3:
            CONTROLS[0].controls[1].controls[0].bgcolor = "green900"
            CONTROLS[0].controls[1].controls[0].width = 130
        else:
            CONTROLS[0].controls[1].controls[0].width = 0

        CONTROLS[0].controls[1].controls[0].opacity = 1
        CONTROLS[0].controls[1].controls[0].update()

        #here, 
        return self.criteria_satisfied(0, strength)
        

    def character_check_status(self, strength):

        if strength == 0:
            CONTROLS[1].controls[1].controls[0].bgcolor = "red"
            CONTROLS[1].controls[1].controls[0].width = 40
        elif strength == 1:
            CONTROLS[1].controls[1].controls[0].bgcolor = "yellow"
            CONTROLS[1].controls[1].controls[0].width = 70
        elif strength == 2:
            CONTROLS[1].controls[1].controls[0].bgcolor = "green400"
            CONTROLS[1].controls[1].controls[0].width = 100
        elif strength == 3:
            CONTROLS[1].controls[1].controls[0].bgcolor = "green900"
            CONTROLS[1].controls[1].controls[0].width = 130
        else:
            CONTROLS[1].controls[1].controls[0].width = 0

        CONTROLS[1].controls[1].controls[0].opacity = 1
        CONTROLS[1].controls[1].controls[0].update()

        return self.criteria_satisfied(1, strength)


    def repeat_check_status(self, strength):
        if strength == 0:
            CONTROLS[2].controls[1].controls[0].bgcolor = "red"
            CONTROLS[2].controls[1].controls[0].width = 65
        elif strength == 1:
            CONTROLS[2].controls[1].controls[0].bgcolor = "green900"
            CONTROLS[2].controls[1].controls[0].width = 130
        else:
            CONTROLS[2].controls[1].controls[0].width = 0

        CONTROLS[2].controls[1].controls[0].opacity=1
        CONTROLS[2].controls[1].controls[0].update()

        if strength == 1:
            strength = 3
            return self.criteria_satisfied(2, strength)
        else:
            return self.criteria_satisfied(2, strength)

    # sequential check

    def sequential_check_status(self, strength):
        if strength == 0:
            CONTROLS[3].controls[1].controls[0].bgcolor = "red"
            CONTROLS[3].controls[1].controls[0].width = 65
        elif strength == 1:
            CONTROLS[3].controls[1].controls[0].bgcolor = "green900"
            CONTROLS[3].controls[1].controls[0].width = 130
        else:
            CONTROLS[3].controls[1].controls[0].width = 0

        CONTROLS[3].controls[1].controls[0].opacity=1
        CONTROLS[3].controls[1].controls[0].update()

        if strength == 1:
            strength = 3
            return self.criteria_satisfied(3, strength)
        else:
            return self.criteria_satisfied(3, strength)
  

    # begore we can use of the returns, we need to do a little bit of UI
    # first, we will handle the strength UI/Logic

    @store_controls
    def check_criteria_display(self, criteria, description, control:int):
        return Row(
            alignment=MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=CrossAxisAlignment.CENTER,
            spacing=5,
            controls=[
                Column(
                    spacing=2,
                    controls=[
                        Text(value=criteria,size=15, weight="bold",color="blue"),
                        Text(value=description,size=9,weight="bold", color="white"),
                    ],
                ),
                #
                Row(
                    spacing=0,
                    alignment=MainAxisAlignment.START,
                    controls=[
                        Container(
                            height=5,
                            opacity=0,
                            animate=350,
                            border_radius=10,
                            animate_opacity=animation.Animation(350,"decelerate"),
                        )
                    ],
                ),
            ],
        )

    # for the final ui now we add a checkbox
    @store_controls
    def check_status_display(self, control:int):
        return Row(
            alignment=MainAxisAlignment.END,
            controls=[
                Container(
                    opacity=0,
                    offset=transform.Offset(-0.5, 0),
                    animate_offset=animation.Animation(600, "decelerate"),
                    animate_opacity=animation.Animation(600, "decelerate"),
                    border_radius=50,
                    width=21,
                    height=21,
                    alignment=alignment.center,
                    content=Checkbox(
                        scale=Scale(0.7),
                        fill_color="#7df6dd",
                        check_color="black",
                        disabled=True,
                    ),
                )
            ],
        )

    # main display area where checks are done
    def password_strength_display(self):
        return Container(
            width=350,
            height=400,
            bgcolor="#1f262f",
            border_radius=15,
            padding=20,
            clip_behavior=ClipBehavior.HARD_EDGE,
            content=Column(
                horizontal_alignment=CrossAxisAlignment.CENTER,
                spacing=-1,
                controls=[
                    Divider(height=5, color="transparent"),
                    Text("Password Strength Check", size=21, weight="bold", color="white"),
                    Text(
                        "Type a pass and see how strong it is!",
                        size=11,
                        color="white",
                        weight="bold",
                    ),
                    Divider(height=5, color="transparent"),
                    # place each criteria here
                    self.check_criteria_display("1. length check", "strong passwords are 12 chars, or above", control=0,),
                    self.check_status_display(control=1),
                    Divider(height=10, color="transparent"),
                    self.check_criteria_display("2. Character check", "upper, lower, and special characters", control=0,),
                    self.check_status_display(control=1),
                     Divider(height=10, color="transparent"),
                    self.check_criteria_display("3. Repeat check", "Checking for any repetitions...", control=0,),
                    self.check_status_display(control=1),
                     Divider(height=10, color="transparent"),
                    self.check_criteria_display("4. Sequential check", "Checking for sequences ...", control=0,),
                    self.check_status_display(control=1),

                ],
            ),
        )

    # User input field
    def password_input_display(self):
        return Card(
            width=300,
            height=60,
            elevation=12,
            color="white",
            offset=transform.Offset(0, -1),
            content=Container(
                padding=padding.only(left=15),
                
                content=Row(
                    alignment=MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        IconButton(
                            icon=icons.COPY, icon_size=16, 
                            on_click=lambda e: set_text_to_clipboard(self.data)  # Corrected line
                        ),
                        self.password_text_field_display(),  # Call to the password_text_field_display method
                    ],
                ),
            ),
        )


    def password_text_field_display(self):

        return Row(
            spacing=20,
            vertical_alignment=CrossAxisAlignment.CENTER,
            controls=[
                Icon(name=icons.LOCK_OUTLINE_ROUNDED, size=14, opacity=0.85),
                TextField(
                    border_color="transparent",
                    bgcolor="transparent",
                    height=20,
                    width=200,
                    text_size=12,
                    content_padding=3,
                    cursor_color="black",
                    cursor_width=1,
                    color="black",
                    hint_text="Start Typing a Password...",
                    hint_style=TextStyle(size=11),
                    on_change=lambda e: self.check_password(e),
                    password=True,can_reveal_password=True
                )
            ],
        )
    def recommend_password_click(self,e):
        password_strength_checker = PasswordStrengthChecker("")
        recommended_password = password_strength_checker.recommend_password()
        #show_recommendation_dialog("Random Password Recommendation", f"Your recommended password is:\n{recommended_password}\n\nPassword copied to clipboard.")
        set_text_to_clipboard(recommended_password)
        
    def build(self):
        return Card(
            elevation=20,
            content=Container(
                width=400,
                height =420,
                border_radius =10,
                bgcolor= "#1f262f",
                content = Column(
                    spacing=0,
                    horizontal_alignment=CrossAxisAlignment.CENTER,
                    controls=[
                        # add main classes here
                        self.password_strength_display(),
                        self.password_input_display(),
                    ]

                )
            ),
        
        
        )


def main(page: Page):
    page.horizontal_alignment ="center"
    page.vertical_alignment = "center"
    page.bgcolor="0xFF00BCD4"
    page.window_maximized = True 
    app_window = AppWindow()
    page.add(app_window)
    button = flet.ElevatedButton(text="Recommendation Button", on_click=lambda _: app_window.recommend_password_click(_))
    page.add(button)
    page.update()


if __name__ == "__main__":
    flet.app(target=main)


